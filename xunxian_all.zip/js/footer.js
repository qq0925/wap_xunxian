/**
 * Created by Administrator on 2016/6/7.
 */
time = new Date();
document.write(time.toLocaleString());
