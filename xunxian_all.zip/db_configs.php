<?php

return [
    'db_host' => '127.0.0.1',
    'db_name' => 'xunxian',
    'db_user' => 'xunxian',
    'db_password' => '123456',
];
?>